alert('hello')
document.write('ali rousta')